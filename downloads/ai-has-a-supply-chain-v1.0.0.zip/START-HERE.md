# Start here

Open tools/episode-06-control-review/index.html for control ownership, tools/episode-07-placement-test/index.html for workload placement, or tools/episode-08-delivery-gates/index.html for a delivery-gate review. Keep each tool folder intact. Try the fictional example first. Nothing is saved automatically.

Visuals and image descriptions are under series/ai-has-a-supply-chain/episode-01 through episode-06. EXERCISES.md contains text-only reviews. Read RELEASE-STATUS.md for exclusions and LICENSE/NOTICE for reuse. No spreadsheet, account, API key or network connection is required.
